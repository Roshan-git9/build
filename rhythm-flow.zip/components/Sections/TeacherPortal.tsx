
import React, { useState, useEffect } from 'react';
import { Student, AcademicMetrics } from '../../types';

interface Props {
  student: Student;
  students: Student[];
  onSelectStudent: (id: string) => void;
  onAddStudent: (name: string) => void;
  onUpdateStudent: (updates: Partial<Student>) => void;
}

export const TeacherPortal: React.FC<Props> = ({ student, students, onSelectStudent, onAddStudent, onUpdateStudent }) => {
  const [formData, setFormData] = useState({
    name: student.name,
    age: student.age || '',
    grade: student.grade || '',
    focusArea: student.focusArea || '',
    remarks: student.remarks || '',
    academicMetrics: student.academicMetrics
  });
  
  const [newStudentName, setNewStudentName] = useState('');

  useEffect(() => {
    setFormData({
      name: student.name,
      age: student.age || '',
      grade: student.grade || '',
      focusArea: student.focusArea || '',
      remarks: student.remarks || '',
      academicMetrics: student.academicMetrics
    });
  }, [student]);

  const handleAdd = () => {
    if (newStudentName.trim()) {
      onAddStudent(newStudentName.trim());
      setNewStudentName('');
    }
  };

  const handleSave = () => {
    onUpdateStudent(formData);
  };

  const updateMetric = (key: keyof AcademicMetrics, value: any) => {
    setFormData({
      ...formData,
      academicMetrics: {
        ...formData.academicMetrics,
        [key]: value
      }
    });
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        <div className="md:col-span-4 tile rgb-border p-8 glow-blue bg-stone-950/20">
          <div className="tile-header mb-6">
            <span className="text-cyan-400 font-bold uppercase tracking-widest">Student Registry</span>
          </div>
          <div className="space-y-6">
             <div className="flex gap-2">
                <input 
                  type="text" 
                  value={newStudentName}
                  onChange={(e) => setNewStudentName(e.target.value)}
                  placeholder="Full Name..."
                  className="flex-1 bg-stone-900 border border-white/5 rounded px-4 py-3 text-[11px] mono text-stone-300 outline-none focus:border-cyan-500/50"
                />
                <button onClick={handleAdd} className="bg-cyan-600 hover:bg-cyan-500 text-stone-950 px-4 py-2 rounded font-bold text-[10px] uppercase">Add</button>
             </div>
             <div className="h-[400px] overflow-y-auto space-y-3 pr-2 scrollbar-thin">
                {students.map(s => (
                  <button
                    key={s.id}
                    onClick={() => onSelectStudent(s.id)}
                    className={`w-full text-left px-5 py-4 rounded-lg border transition-all relative overflow-hidden group ${s.id === student.id ? 'bg-cyan-900/20 border-cyan-500/40 text-cyan-400' : 'bg-stone-900/40 border-white/5 text-stone-500 hover:border-white/20'}`}
                  >
                    <div className="text-[11px] mono font-bold uppercase tracking-wider">{s.name}</div>
                    <div className="text-[9px] mono opacity-40 uppercase mt-1">{s.grade || '??'} Grade • {s.age || '??'} yrs</div>
                  </button>
                ))}
             </div>
          </div>
        </div>

        <div className="md:col-span-8 tile rgb-border p-10 glow-red bg-stone-950/40">
          <div className="tile-header mb-8">
            <span className="rgb-text font-bold uppercase tracking-[0.2em]">Data Entry: {student.name}</span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Assignment Count</label>
               <input type="number" value={formData.academicMetrics.assignmentSubmissionCount} onChange={(e) => updateMetric('assignmentSubmissionCount', parseInt(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Attendance Drop %</label>
               <input type="number" step="0.1" value={formData.academicMetrics.attendanceDropPercentage} onChange={(e) => updateMetric('attendanceDropPercentage', parseFloat(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Marks Drop (Pts)</label>
               <input type="number" step="0.1" value={formData.academicMetrics.marksDropBetweenTerms} onChange={(e) => updateMetric('marksDropBetweenTerms', parseFloat(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Late Ratio (0-1)</label>
               <input type="number" step="0.01" value={formData.academicMetrics.lateSubmissionRatio} onChange={(e) => updateMetric('lateSubmissionRatio', parseFloat(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Attendance Trend</label>
               <select value={formData.academicMetrics.attendanceTrend} onChange={(e) => updateMetric('attendanceTrend', e.target.value)} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30">
                 <option value="stable">Stable</option>
                 <option value="rising">Rising</option>
                 <option value="falling">Falling</option>
               </select>
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Grade Variance</label>
               <input type="number" step="0.1" value={formData.academicMetrics.gradeVariance} onChange={(e) => updateMetric('gradeVariance', parseFloat(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
             <div className="space-y-2">
               <label className="mono text-[8px] text-stone-500 uppercase">Missing Streak</label>
               <input type="number" value={formData.academicMetrics.missingAssignmentStreak} onChange={(e) => updateMetric('missingAssignmentStreak', parseInt(e.target.value))} className="w-full bg-stone-900/60 border border-white/5 rounded px-4 py-2 text-stone-200 mono text-xs outline-none focus:border-magenta-500/30" />
             </div>
          </div>

          <div className="space-y-2 mb-8">
            <label className="mono text-[8px] text-stone-500 uppercase">Qualitative Remarks</label>
            <textarea value={formData.remarks} onChange={(e) => setFormData({...formData, remarks: e.target.value})} className="w-full h-32 bg-stone-900/60 border border-white/5 rounded p-4 text-stone-100 mono text-xs outline-none focus:border-magenta-500/40" />
          </div>

          <div className="flex justify-end">
            <button onClick={handleSave} className="px-8 py-3 bg-magenta-600 hover:bg-magenta-500 text-white font-bold text-[10px] tracking-[0.3em] uppercase rounded-full glow-red">Commit Data</button>
          </div>
        </div>
      </div>
    </div>
  );
};
